# AFTUNE 推理完整性实验结果（v3）

GPU 推理与证据记录，CPU 验证；FP32；B_L=2、I_A=4；Serving 仅 r6；采样率 8%。

六类实验共享 224 个阴性生成样本，各有 32 个阳性；共 416 个正式目标生成任务、640 条去重序列证据、1,536 次条件统计引用。共享样本及重复抽样不增加独立样本量。 六类阳性使用同一组 32 个输入索引、各自注入；条件间的统计相关性应保留。

| 条件/证据 | TP | FN | FP | TN | ERROR | TPR | FPR | Precision | F1 | TPR 95% Wilson | FPR 95% Wilson |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|---|
| 0/kv_cache/generation_live | 32 | 0 | 14 | 210 | 0 | 100.00% | 6.25% | 69.57% | 82.05% | [89.28%, 100.00%] | [3.76%, 10.22%] |
| 0/serving_config/generation_live | 5 | 27 | 14 | 210 | 0 | 15.62% | 6.25% | 26.32% | 19.61% | [6.86%, 31.75%] | [3.76%, 10.22%] |
| 0/model_mismatch/model_recompute_live | 1 | 31 | 3 | 221 | 0 | 3.12% | 1.34% | 25.00% | 5.56% | [0.55%, 15.74%] | [0.46%, 3.86%] |
| 0/token_selection/generation_live | 4 | 28 | 14 | 210 | 0 | 12.50% | 6.25% | 22.22% | 16.00% | [4.97%, 28.07%] | [3.76%, 10.22%] |
| 0/computation/generation_live | 32 | 0 | 14 | 210 | 0 | 100.00% | 6.25% | 69.57% | 82.05% | [89.28%, 100.00%] | [3.76%, 10.22%] |
| 0/input_mismatch/generation_live | 8 | 24 | 14 | 210 | 0 | 25.00% | 6.25% | 36.36% | 29.63% | [13.25%, 42.11%] | [3.76%, 10.22%] |

## 8% 抽样结果

D 每轮抽取 70/864 个单元；Model 抽取 1/9 个块。每份源证据重复 1,000 次，五类 D 实验复用共享阴性的同一套抽样。以下为相关重复的汇总，不据此计算独立请求置信区间。

| 条件/证据 | 采样 TP | FN | FP | TN | 错误 | 采样 TPR | 采样 FPR |
|---|---:|---:|---:|---:|---:|---:|---:|
| 0/kv_cache/generation_live | 5088 | 26912 | 8678 | 215322 | 0 | 15.90% | 3.87% |
| 0/serving_config/generation_live | 2871 | 29129 | 8678 | 215322 | 0 | 8.97% | 3.87% |
| 0/model_mismatch/model_recompute_live | 260 | 31740 | 331 | 223669 | 0 | 0.81% | 0.15% |
| 0/token_selection/generation_live | 2580 | 29420 | 8678 | 215322 | 0 | 8.06% | 3.87% |
| 0/computation/generation_live | 5132 | 26868 | 8678 | 215322 | 0 | 16.04% | 3.87% |
| 0/input_mismatch/generation_live | 6325 | 25675 | 8678 | 215322 | 0 | 19.77% | 3.87% |

## 严格输出哈希模式

GPU 与 CPU 的正常 FP32 数值差异也可能产生哈希不一致；该模式单列，不能直接把哈希拒绝解释为违例。

| 条件/证据 | TP | FN | FP | TN | ERROR |
|---|---:|---:|---:|---:|---:|
| 0/kv_cache/generation_live | 32 | 0 | 224 | 0 | 0 |
| 0/serving_config/generation_live | 32 | 0 | 224 | 0 | 0 |
| 0/model_mismatch/model_recompute_live | 32 | 0 | 224 | 0 | 0 |
| 0/token_selection/generation_live | 32 | 0 | 224 | 0 | 0 |
| 0/computation/generation_live | 32 | 0 | 224 | 0 | 0 |
| 0/input_mismatch/generation_live | 32 | 0 | 224 | 0 | 0 |

## 复现与边界

D/Model 冻结阈值：`{'generation_live': 1.169039629035759e-06, 'model_recompute_live': 4.159917741857746e-07}`。

配置 SHA-256：`661b86da1383d02ce6efa4c8aaecbeb6c5898169b6b725df742d72c077c116f0`。

语料 SHA-256：`e1c4ed97cf2c7ef6962b652600db22f60e9634c939d519b4332dd577c9f2674b`。

运行目录：`/home/yliangh/projects/aftune-workspace/.cache/experiment-runs/aftune-inference-integrity-seed0-cal32-v3`。完整性审计通过，抽样结果已由保存的源证据标识和种子重建核对。

稀疏记录初始仅保存块 0、4、8 的激活；全量审计准备阶段揭示真实前向暂存的其余原始边界张量并核验原承诺，不使用干净重算替换。补齐会增加实际存储及执行开销，相关成本保存在各任务 commitment 与 summary 中。

这是固定 seed、小模型、短输入的机制评估。KV 为完整前缀模拟，Serving 为数值舍入代理；未实施 TEE 远程认证。Model 重算通过只能证明提交的 Llama trace 自洽，不能证明源文本由 Llama 生成。

## 补充核验与结果解释

正式运行前的完整长度 GPU→CPU 预检已通过，覆盖共享干净请求及六种注入。其配置与核心代码指纹与正式运行一致；诊断阈值未并入正式实验。正式校准使用 32 个独立正常请求，完成后冻结的 D/Model 阈值与暂停检查点完全一致。

六类各 32 个阳性均注入成功；每类 256 个统计引用全部可判定，样本执行错误、不支持和未知注入数均为 0。各类 deployment recall 等于上表数值主模式 TPR。严格哈希模式六类均为 TPR=100%、FPR=100%、precision=12.50%、F1=22.22%；其 TPR 95% Wilson 区间为 [89.28%,100%]，FPR 区间为 [98.31%,100%]。

本轮 Model 阳性的 Qwen prompt 实际为 30 tokens（1 条）或 31 tokens（31 条），每条生成 96 个源 tokenizer tokens，源序列总长分别为 126 或 127。Llama 文本桥接后的总长为 115–131 tokens，其中 14 条为 128；224 个共享阴性的桥接总长均为 128。桥接保留实际 token IDs，没有为对齐长度而补齐或截断，故跨模型条件包含序列长度差异。所有 256 条 Model 证据的桥接 token IDs 已依据冻结 tokenizer 重新核对。

Token Selection 的 4 个数值拒绝中，索引 105 在第 43 步替换前已出现 10 个拒绝块；索引 235 在第 94 步替换前已出现全部 23 个拒绝块。数值模式按预定标签将这两条计为 TP，但这些拒绝不能直接归因于选词替换。Model 提交的是 Llama 重算 trace，Input 提交的是实际执行输入的 trace；这类 trace 的数值判定不单独证明源模型身份或原始客户端输入绑定。

Computation 的实际扰动相对 L2 范围为 0.0099999823–0.0100000144，32/32 的拒绝均覆盖实际注入的层块。Serving 的 32 次 r6 切换及切换后全部层/步的舍入事件、32 次选词替换和 32 次输入段交换也已逐项核对。

每个正式源任务只计一次成本。416 个任务累计产生约 204.35 GiB 证据，其中稀疏基础记录约 68.23 GiB、补齐张量约 135.95 GiB；累计产出包括随后按方案释放的临时记录。共有 37,120 份原生记录完成激活准备。索引 0、64、128、192 的 D 与 Model 张量全部保留，388 份准备记录均核实初始输出块为 0、4、8，补齐块为 1、2、3、5、6、7，且补齐响应与原输出哈希一致。校准、失败/中断重试和参考模型不并入上述正式任务成本。

首次完成审计时，审计器将内存中的 Wilson 区间 tuple 与 JSON 读回的 list 直接比较，造成 12 项摘要误拒绝。仅修正了审计比较表示，全部数值保持一致；恢复流程复用全部已完成样本并重新通过全量审计。修复前后 3,203 个原始结果、语料、配置和阈值文件哈希一致，冻结的实验/验证核心代码未变。第一次失败的审计、旧审计脚本和前后文件哈希保存在诊断目录。暂停时未完成的首条 KV 尝试也保留在其诊断目录，正式统计使用恢复后的完成版本。

可复查文件：[正式摘要](/home/yliangh/projects/aftune-workspace/.cache/experiment-runs/aftune-inference-integrity-seed0-cal32-v3/summary.json)、[完整性审计](/home/yliangh/projects/aftune-workspace/.cache/experiment-runs/aftune-inference-integrity-seed0-cal32-v3/completion_audit.json)、[补充审计](/home/yliangh/projects/aftune-workspace/.cache/experiment-runs/aftune-inference-integrity-seed0-cal32-v3/completion_review.json)、[补充审计脚本](/home/yliangh/projects/aftune-workspace/.cache/experiment-runs/aftune-inference-integrity-seed0-cal32-v3/completion_review.py)、[审计恢复说明](/home/yliangh/projects/aftune-workspace/.cache/experiment-runs/aftune-inference-integrity-seed0-cal32-v3/audit_recovery.json)。
