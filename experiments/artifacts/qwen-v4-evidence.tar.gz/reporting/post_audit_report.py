"""Document verified v3/v4 differences without changing frozen runtime/results."""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import json
import math
from pathlib import Path

REPO = Path('/home/yliangh/projects/aftune-workspace/AFTUNE')
BASE = REPO.parent / '.cache/experiment-runs'
ROOT = BASE / 'aftune-inference-integrity-qwen-seed0-cal32-v4'
OLD = BASE / 'aftune-inference-integrity-seed0-cal32-v3'

def read(path):
    return json.loads(path.read_text())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def distribution(values):
    return {'count': len(values), 'min': min(values), 'max': max(values),
            'mean': math.fsum(values)/len(values),
            'histogram': dict(sorted(Counter(values).items()))}

def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n')

state, audit, summary, manifest = [read(ROOT/name) for name in
    ('runner_state.json', 'completion_audit.json', 'summary.json', 'manifest.json')]
assert state['status'] == 'complete' and state['audit_passed'] is True
assert audit['passed'] is True and not audit['issues'] and not audit['issue_counts']
assert audit['full_sampling_reconstruction'] is True and summary['complete']
assert (summary['unique_generation_tasks'], summary['unique_sequence_evidence'],
        summary['condition_sample_references']) == (416,640,1536)
assert digest(ROOT/'thresholds.json') == '6db7c1505a41f45171c7593bc44695c794cfd163414cf4a0432267a49db3cf75'
old_manifest, old_summary = read(OLD/'manifest.json'), read(OLD/'summary.json')
provenance = manifest['paired_reference']
for name, field in [('manifest.json','reference_manifest_sha256'),
                    ('corpus.json','reference_corpus_sha256'),
                    ('summary.json','reference_summary_sha256')]:
    assert digest(OLD/name) == provenance[field]
for name, expected in provenance['reference_schedule_files'].items():
    assert digest(OLD/name) == expected
fingerprints = {}
for label, package, doc in [('v3','inference_integrity',old_manifest),
                             ('v4','inference_integrity_qwen',manifest)]:
    for name, expected in doc['experiment_code_sha256'].items():
        path = REPO/'experiments'/package/name
        if not path.exists():
            path = REPO/name
        assert digest(path) == expected, str(path)
    fingerprints[label] = len(doc['experiment_code_sha256'])

old_corpus, corpus = read(OLD/'corpus.json'), read(ROOT/'corpus.json')
assert old_corpus['positive_indices'] == corpus['positive_indices']
paired = []
for partition, old_rows, rows in [('calibration',old_corpus['calibration'],corpus['calibration']),
                                  ('evaluation',old_corpus['evaluation']['0'],corpus['evaluation']['0'])]:
    assert len(old_rows) == len(rows)
    for index,(previous,current) in enumerate(zip(old_rows,rows)):
        identity = ('source_file','source_row','source_text_sha256')
        assert all(previous[k] == current[k] for k in identity)
        assert len(previous['input_ids']) == len(current['input_ids']) == 32
        assert previous['input_ids'][0] == 128000
        paired.append({'partition':partition,'index':index,
                       **{k:current[k] for k in identity},
                       'v3_request_text':previous['request_text'],
                       'v4_request_text':current['request_text'],
                       'v3_input_ids':previous['input_ids'],
                       'v4_input_ids':current['input_ids'],
                       'v3_request_text_sha256':previous['request_text_sha256'],
                       'v4_request_text_sha256':current['request_text_sha256'],
                       'request_text_identical':previous['request_text']==current['request_text']})
assert len(paired) == 288

lengths, kv_layers, sampling = {}, {}, {}
for label, root in [('v3',OLD),('v4',ROOT)]:
    lengths[label] = {}
    for condition, paths in [('shared_clean',sorted(root.glob('shared_clean/0/*/oracle/truth.json'))),
                             ('model_mismatch',sorted(root.glob('cases/0/model_mismatch/*/oracle/truth.json')))]:
        rows = [read(p) for p in paths]
        assert len(rows) == (224 if condition=='shared_clean' else 32)
        sources = [row['source_generation'] if condition=='model_mismatch' else row['generation'] for row in rows]
        lengths[label][condition] = {'source_prompt':distribution([len(s['input_ids']) for s in sources]),
                                     'source_total':distribution([len(s['full_ids']) for s in sources]),
                                     'bridge':distribution([len(row['declared_retokenized_ids']) for row in rows]),
                                     'recompute_input':distribution([len(row['declared_retokenized_ids'])-1 for row in rows])}
    kv_paths = sorted(root.glob('cases/0/kv_cache/*/oracle/truth.json'))
    assert len(kv_paths) == 32
    kv_layers[label] = dict(sorted(Counter(read(p)['spec']['layer'] for p in kv_paths).items()))
    sampling[label] = {}
    for origin in ('generation_live','model_recompute_live'):
        row = read(root/'shared_clean/0/0000'/origin/'result.json')
        sample, = row['sampling']
        sampling[label][origin] = {'units':row['block_count'],'sample_count':sample['sample_count'],
                                   'actual_rate':sample['sample_count']/row['block_count']}

exceptions = {}
for key, group in summary['groups'].items():
    assert group['observed_cases'] == group['expected_cases'] == 256
    exceptions[key] = {}
    for mode in ('numeric','strict_hash'):
        m = group[mode]; c = m['counts']
        exceptions[key][mode] = {'successful_positive':m['successful_positive'],
            'injection_success_rate':m['injection_success_rate'],
            'execution_or_verification_errors':c.get('ERROR',0),
            'injection_failed':c.get('INJECTION_FAILED',0),
            'injection_status_unknown':m['injection_status_unknown'],
            'unsupported':c.get('UNSUPPORTED',0)}
        assert m['successful_positive'] == 32 and m['injection_success_rate'] == 1
        assert all(exceptions[key][mode][name] == 0 for name in
                   ('execution_or_verification_errors','injection_failed','injection_status_unknown','unsupported'))

calibration = [read(p) for p in sorted(ROOT.glob('calibration/*/calibration.json'))]
assert len(calibration) == 32
gate = read(ROOT/'preflight_gate.json')
preflight = read(Path(gate['path'])/'preflight.json')
assert preflight['passed'] is True and digest(Path(gate['path'])/'preflight.json') == gate['preflight_sha256']
interrupted = [str(p.relative_to(ROOT)) for p in ROOT.glob('cases/0/*/_diagnostics/*') if p.is_dir()]
costs = {'formal_sources':416,'formal_unique_evidence':640,'view_references':1536,
         'calibration_sources_excluded':32,
         'calibration_elapsed_seconds':math.fsum(float(row['elapsed_seconds']) for row in calibration),
         'formal_bridge_recomputations_auxiliary':256,
         'kv_donor_generations_auxiliary':32,
         'donor_seconds_separate_stage':summary['actual_costs']['stage_seconds']['donor_generation'],
         'formal_stages_seconds':summary['actual_costs']['stage_seconds'],
         'formal_proof_bytes':summary['actual_costs']['proof_bytes'],
         'passed_preflight_seconds_excluded':preflight['elapsed_seconds'],
         'failed_initial_preflight_excluded':str(ROOT.with_name(ROOT.name+'-preflight')),
         'interrupted_attempts_excluded':interrupted,
         'note':'Calibration, diagnostics and interrupted attempts are not independent formal observations. Formal stage totals include the separately named auxiliary donor stage. No unrecorded retry duration is inferred.'}
comparison = {'created_at':datetime.now(timezone.utc).isoformat(),
    'post_audit_analysis_only':True,'report_generator_sha256':digest(Path(__file__)),
    'source_hashes':{'v3_manifest':digest(OLD/'manifest.json'),'v4_manifest':digest(ROOT/'manifest.json'),
                     'v3_summary':digest(OLD/'summary.json'),'v4_summary':digest(ROOT/'summary.json'),
                     'completion_audit':digest(ROOT/'completion_audit.json')},
    'paired_input_count':len(paired),'identical_request_text_count':sum(row['request_text_identical'] for row in paired),
    'v3_prompt_policy':'BOS 128000 plus 31 content tokens; request decodes content only',
    'v4_prompt_policy':'32 content tokens; no BOS or chat template; request decodes all 32',
    'paired_inputs':paired,'lengths':lengths,
    'kv_eligible_layers':{'v3':list(range(16)),'v4':manifest['model_profile']['kv_eligible_layers']},
    'kv_selected_layer_counts':kv_layers,'sampling':sampling,
    'exceptions':exceptions,'costs':costs,'unchanged_runtime_code_files':fingerprints,
    'inference_limits':'Paired source rows and injection timing do not make token prefixes, model direction, eligible KV populations, audit grids or independent sample counts identical. Repeated sampling and shared aliases are correlated.'}
out = ROOT/'paired_comparison.json'
write(out,comparison)

report = Path(state['report'])
base_report = report.read_text().split('\n<!-- post-audit-comparison -->')[0]
base_report = base_report.replace('\n## 严格输出哈希模式','\n\n## 严格输出哈希模式')
thresholds = read(ROOT/'thresholds.json')
paragraph = ('seed 0、FP32、batch size 1、use_cache=False；GPU 推理与记录，CPU 验证固定 8 线程。'
             f'32 条全新校准冻结阈值：D={thresholds["thresholds"]["generation_live"]:.17g}，'
             f'Model={thresholds["thresholds"]["model_recompute_live"]:.17g}；冻结时间 {thresholds["created_at"]}，正式结果未用于调阈值。\n\n')
if paragraph not in base_report:
    base_report = base_report.replace('B_L=2、I_A=4、原生B_S=1；',paragraph+'B_L=2、I_A=4、原生B_S=1；',1)
lines = ['', '<!-- post-audit-comparison -->', '', '## 配对文本、桥接与 KV 覆盖补充', '',
    f'288 个数据行按原索引、source_row 和原文 SHA-256 逐一对应；两轮请求文本完全相同的只有 {comparison["identical_request_text_count"]}/288。v3 输入是 BOS＋31 个 Llama 内容 token，请求文本只解码内容；v4 输入是无 BOS 的 32 个 Qwen 内容 token，请求文本解码全部 32 个。逐行的两份实际请求文本、IDs、哈希见 `'+str(out)+'`。', '',
    'v3 的声明/替代方向为 Llama→Qwen，v4 为 Qwen→Llama。以下源长度和桥接长度均取自实际保存 IDs；Qwen 重算输入为桥接序列去掉最后一个 token。', '',
    '| 项目 | v3 | v4 |','|---|---|---|']
for condition,title in [('shared_clean','224 个共享阴性'),('model_mismatch','32 个 Model 阳性')]:
    for field,label in [('source_prompt','替代/生成源 prompt 长度'),('bridge','声明模型桥接总长度'),('recompute_input','重算输入长度')]:
        a,b = lengths['v3'][condition][field],lengths['v4'][condition][field]
        lines.append(f'| {title}：{label} | {a["min"]}–{a["max"]}，均值 {a["mean"]:.5f} | {b["min"]}–{b["max"]}，均值 {b["mean"]:.5f} |')
lines += ['',f'v3 Model 阳性桥接长度分布：`{lengths["v3"]["model_mismatch"]["bridge"]["histogram"]}`。',
    f'v4 Model 阳性桥接长度分布：`{lengths["v4"]["model_mismatch"]["bridge"]["histogram"]}`。','',
    'v3 KV 可选总体为 0–15 的全部 16 个 full-attention 层，正式阳性选中其中 13 层；v4 可选总体仅为 3/7/11/15/19/23 的 6 个 full-attention 层，全部覆盖。18 个 linear-attention 层不属于本次传统历史 K/V 槽替换总体。',
    f'v3 实际选层计数：`{kv_layers["v3"]}`；v4：`{kv_layers["v4"]}`。','',
    '| 审计网格 | v3 每轮实际采样 | v4 每轮实际采样 |','|---|---|---|']
for origin,title in [('generation_live','D'),('model_recompute_live','Model')]:
    a,b=sampling['v3'][origin],sampling['v4'][origin]
    lines.append(f'| {title} | {a["sample_count"]}/{a["units"]} = {100*a["actual_rate"]:.6f}% | {b["sample_count"]}/{b["units"]} = {100*b["actual_rate"]:.6f}% |')
lines += ['', '## 错误与注入失败单列', '',
    '下表按独立阳性请求计数；数值和严格哈希模式共用相同执行及真值记录。拒绝或漏检均不改写为注入失败。', '',
    '| 条件 | 成功注入 | 执行/验证错误 | 注入失败 | 真值未知 | 不支持 |','|---|---:|---:|---:|---:|---:|']
for key,modes in exceptions.items():
    m=modes['numeric']
    lines.append(f'| {key.split("/")[1]} | {m["successful_positive"]}/32 | {m["execution_or_verification_errors"]} | {m["injection_failed"]} | {m["injection_status_unknown"]} | {m["unsupported"]} |')
lines += ['', '224 个共享阴性没有执行/验证错误。数值 D 证据误报为 0/224，Model 证据为 2/224（索引 108、121）；严格哈希模式两类阴性均为 224/224 误报，不能把该模式的 100% 阳性拒绝率解读为有效区分能力。','',
    '## 去重与辅助成本口径', '',
    f'正式统计仍为 416 个源任务、640 份去重证据和 1,536 次视图引用；证据累计产出 {costs["formal_proof_bytes"]:,} 字节。正式任务的阶段时间包括单列的 32 次 KV donor 生成（{costs["donor_seconds_separate_stage"]:.6f} 秒），donor 不扩大源任务数。224 个阴性与 32 个 Model 阳性共 256 次桥接重算不作为额外源生成任务。', '',
    f'另计 32 个校准源任务，校准标记累计耗时 {costs["calibration_elapsed_seconds"]:.6f} 秒；通过的完整预检耗时 {costs["passed_preflight_seconds_excluded"]:.6f} 秒。最初 BF16 预检失败和用户暂停导致的 {len(interrupted)} 个中断尝试保留在诊断目录，均不进入正式 N、阈值或成功任务耗时；未记录的重试耗时不作推算。参考快照准备另计。', '',
    '每类视图的独立请求数为 256，其中 224 个阴性在六类间共享；抽样的 1,000 次重复相关，不作为新增独立样本，不据此给出独立 Bernoulli 试验的 Wilson 区间。两轮对照基于同源数据行与配对时序，不预设同一检出率，也不能将差异单独归因于模型大小。', '',
    '## 验收证据', '',
    f'`completion_audit.json` 在 {audit["audited_at"]} 通过，重建全部 640×1,000 轮抽样；六个 256 样本视图、13 块网格、共享引用、真值及成本均已核对。37120 份原始激活准备记录中按方案保留 388 份（索引 0/64/128/192），每份含 4 个初始输出与 9 个原始揭示输出及承诺核验。', '',
    f'运行结束后再次核验 v3 的 {fingerprints["v3"]} 个、v4 的 {fingerprints["v4"]} 个代码指纹，无不匹配；v3 manifest/语料/汇总和全部配对时序文件保持原哈希。', '',
    f'完整机器可读对照：`{out}`，SHA-256：`{digest(out)}`。补充报告脚本保存在结果目录 `reporting/post_audit_report.py`，其指纹已写入对照 JSON；不修改冻结的运行代码、阈值、评分或判定。','']
report.write_text(base_report+'\n'.join(lines))
repository_report = REPO/'experiments/inference_integrity_qwen/实验结果.md'
repository_report.write_bytes(report.read_bytes())
archive=ROOT/'reporting';archive.mkdir(exist_ok=True)
(archive/'post_audit_report.py').write_bytes(Path(__file__).read_bytes())
review={'reviewed_at':datetime.now(timezone.utc).isoformat(),'passed':True,
    'full_audit_sha256':digest(ROOT/'completion_audit.json'),
    'comparison_sha256':digest(out),'report_sha256':digest(report),
    'repository_report_copy':str(repository_report),
    'repository_report_copy_sha256':digest(repository_report),
    'report_generator_sha256':digest(Path(__file__)),
    'checked':{'terminal_complete':True,'all_416_640_1536':True,'all_sampling_reconstructed':True,
               'calibration_32_and_frozen_thresholds':True,'paired_288_rows':True,
               'all_192_injections_successful':True,'both_mode_metrics_and_intervals_in_report':True,
               'exceptions_separate':True,'actual_lengths_layers_sampling_explicit':True,
               'deduplicated_and_auxiliary_costs_explicit':True,
               'repository_report_copy_identical':repository_report.read_bytes()==report.read_bytes(),
               'v3_and_v4_runtime_fingerprints_match':True,'retention_388_full_audit_passed':True}}
write(ROOT/'post_audit_review.json',review)
print(json.dumps({'report':str(report),'comparison':str(out),'review':str(ROOT/'post_audit_review.json'),
                  'paired_rows':len(paired),'identical_texts':comparison['identical_request_text_count'],
                  'unchanged_code_files':fingerprints,'report_bytes':report.stat().st_size},ensure_ascii=False))
